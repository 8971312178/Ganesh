package com.tataelxsi.websocket;

import javax.enterprise.context.ApplicationScoped;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import javax.websocket.Session;
import com.tataelxsi.constant.AirConditioners;
import com.tataelxsi.constant.Appliances;
import com.tataelxsi.constant.BabyCare;
import com.tataelxsi.constant.BabyClothing;
import com.tataelxsi.constant.BabyKids;
import com.tataelxsi.constant.Books;
import com.tataelxsi.constant.Controllers;
import com.tataelxsi.constant.DesktopPC;
import com.tataelxsi.constant.EducationalBooks;
import com.tataelxsi.constant.Electronics;
import com.tataelxsi.constant.Furniture;
import com.tataelxsi.constant.Gaming;
import com.tataelxsi.constant.Headsets;
import com.tataelxsi.constant.HealthCareAppliances;
import com.tataelxsi.constant.HomeDecor;
import com.tataelxsi.constant.HomeFurniture;
import com.tataelxsi.constant.IndianBooks;
import com.tataelxsi.constant.Keyboards;
import com.tataelxsi.constant.KidsFootwear;
import com.tataelxsi.constant.KitchenDining;
import com.tataelxsi.constant.Laptop;
import com.tataelxsi.constant.LightingStore;
import com.tataelxsi.constant.Mobile;
import com.tataelxsi.constant.Mouse;
import com.tataelxsi.constant.MousePads;
import com.tataelxsi.constant.PhilosophyBooks;
import com.tataelxsi.constant.Refrigerators;
import com.tataelxsi.constant.Religion;
import com.tataelxsi.constant.SmallHomeAppliances;
import com.tataelxsi.constant.Tablet;
import com.tataelxsi.constant.Televisions;
import com.tataelxsi.constant.Toys;
import com.tataelxsi.constant.WashingMachines;
import com.tataelxsi.constant.WebSocketNavigationConstants;
import com.tataelxsi.model.Item;

import javax.json.JsonObject;
import javax.json.spi.JsonProvider;

import java.util.logging.Level;
import java.util.logging.Logger;

	/**
	 * Web Socket Session Handler Operations.
	 * 
	 * @author Ganesh Devulapalli
	 * 
	 */
@ApplicationScoped
public class ItemSessionHandler {

	/*
	 * Set to storing the list of items added to the application and the active
	 * sessions in the application and import their packages
	 */

	private final Set<Session> sessions = new HashSet<>();

	/**
	 * 
	 * @param item
	 *            the Item shows the list ElectronicsItems from the Menu
	 */
	public void showElectronicsItems(Item item) {
		JsonProvider provider = JsonProvider.provider();
		JsonObject addMessage = provider
				.createObjectBuilder()
				.add(WebSocketNavigationConstants.NAME,
						Electronics.ElectronicsEnum.getElectronicsEnum())
				.add(WebSocketNavigationConstants.ACTION,
						WebSocketNavigationConstants.ELECTRONICS).build();
		sendToAllConnectedSessions(addMessage);
	}

	/**
	 * 
	 * @param item
	 *            the Item shows the list Appliances Items from the Menu
	 */
	public void showAppliances(Item item) {
		JsonProvider provider = JsonProvider.provider();
		JsonObject addMessage = provider
				.createObjectBuilder()
				.add(WebSocketNavigationConstants.NAME,
						Appliances.AppliancesEnum.getAppliancesEnum())
				.add(WebSocketNavigationConstants.ACTION,
						WebSocketNavigationConstants.APPLIANCES).build();
		sendToAllConnectedSessions(addMessage);

	}

	/**
	 * 
	 * @param item
	 *            the Item shows the list Baby Kids Items from the Menu
	 */
	public void showBabyKids(Item item) {
		JsonProvider provider = JsonProvider.provider();
		JsonObject addMessage = provider
				.createObjectBuilder()
				.add(WebSocketNavigationConstants.NAME,
						BabyKids.BabyKidsEnum.getBabyKidsEnum())
				.add(WebSocketNavigationConstants.ACTION,
						WebSocketNavigationConstants.BABY_KIDS).build();
		sendToAllConnectedSessions(addMessage);

	}

	/**
	 * 
	 * @param item
	 *            the Item shows the list Home Furniture Items from the Menu
	 */
	public void showHomeFurniture(Item item) {
		JsonProvider provider = JsonProvider.provider();
		JsonObject addMessage = provider
				.createObjectBuilder()
				.add(WebSocketNavigationConstants.NAME,
						HomeFurniture.HomeFurnitureEnum.getHomeFurnitureEnum())
				.add(WebSocketNavigationConstants.ACTION,
						WebSocketNavigationConstants.HOME_FURNNITURE).build();
		sendToAllConnectedSessions(addMessage);
	}

	/**
	 * 
	 * @param item
	 *            the Item shows the list Books Items from the Menu
	 */

	public void showBooks(Item item) {
		JsonProvider provider = JsonProvider.provider();
		JsonObject addMessage = provider
				.createObjectBuilder()
				.add(WebSocketNavigationConstants.NAME,
						HomeFurniture.HomeFurnitureEnum.getHomeFurnitureEnum())
				.add(WebSocketNavigationConstants.ACTION,
						WebSocketNavigationConstants.BOOKS).build();
		sendToAllConnectedSessions(addMessage);
	}

	/**
	 * 
	 * @param item
	 *            the Item shows the list Gaming Items from the Menu
	 */

	public void showGaming(Item item) {
		JsonProvider provider = JsonProvider.provider();
		JsonObject addMessage = provider
				.createObjectBuilder()
				.add(WebSocketNavigationConstants.NAME,
						Gaming.GamingEnum.getGamingEnum())
				.add(WebSocketNavigationConstants.ACTION,
						WebSocketNavigationConstants.GAMING).build();
		sendToAllConnectedSessions(addMessage);
	}

	/**
	 * 
	 * @param item
	 *            the Item Shows the list of Items parameters specified by the
	 *            user in the client
	 */
	public void showSubCategoryItems(Item item) {
		if (item.getName().equalsIgnoreCase(
				Electronics.ElectronicsEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							Mobile.MobileEnum.getMobileEnum())
					.add(WebSocketNavigationConstants.ACTION,
							Mobile.MobileEnum.getMobileEnum()).build();
			sendToAllConnectedSessions(addMessage);
		} else if (item.getName().equalsIgnoreCase(
				Electronics.ElectronicsEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							Laptop.LaptopEnum.getLaptopEnum())
					.add(WebSocketNavigationConstants.ACTION,
							Laptop.LaptopEnum.getLaptopEnum()).build();
			sendToAllConnectedSessions(addMessage);
		} else if (item.getName().equalsIgnoreCase(
				Electronics.ElectronicsEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							Tablet.TabletEnum.getTabletEnum())
					.add(WebSocketNavigationConstants.ACTION,
							Tablet.TabletEnum.getTabletEnum()).build();
			sendToAllConnectedSessions(addMessage);
		}

		else if (item.getName().equalsIgnoreCase(
				Electronics.ElectronicsEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							DesktopPC.DesktopPCEnum.getDesktopPcEnum())
					.add(WebSocketNavigationConstants.ACTION,
							DesktopPC.DesktopPCEnum.getDesktopPcEnum()).build();
			sendToAllConnectedSessions(addMessage);
		}

		else if (item.getName().equalsIgnoreCase(
				Appliances.AppliancesEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							WashingMachines.WashingMachinesEnum
									.getWashingMachinesEnum())
					.add(WebSocketNavigationConstants.ACTION,
							WashingMachines.WashingMachinesEnum
									.getWashingMachinesEnum()).build();
			sendToAllConnectedSessions(addMessage);
		} else if (item.getName().equalsIgnoreCase(
				Appliances.AppliancesEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							Televisions.TelevisionsEnum.getTelevisionsEnum())
					.add(WebSocketNavigationConstants.ACTION,
							Televisions.TelevisionsEnum.getTelevisionsEnum())
					.build();
			sendToAllConnectedSessions(addMessage);
		} else if (item.getName().equalsIgnoreCase(
				Appliances.AppliancesEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							Refrigerators.RefrigeratorsEnum
									.getRefrigeratorsEnum())
					.add(WebSocketNavigationConstants.ACTION,
							Refrigerators.RefrigeratorsEnum
									.getRefrigeratorsEnum()).build();
			sendToAllConnectedSessions(addMessage);
		} else if (item.getName().equalsIgnoreCase(
				Appliances.AppliancesEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							AirConditioners.AirConditionersEnum
									.getAirConditionersEnum())
					.add(WebSocketNavigationConstants.ACTION,
							AirConditioners.AirConditionersEnum
									.getAirConditionersEnum()).build();
			sendToAllConnectedSessions(addMessage);
		} else if (item.getName().equalsIgnoreCase(
				Appliances.AppliancesEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							SmallHomeAppliances.SmallHomeAppliancesEnum
									.getSmallHomeAppliancesEnum())
					.add(WebSocketNavigationConstants.ACTION,
							SmallHomeAppliances.SmallHomeAppliancesEnum
									.getSmallHomeAppliancesEnum()).build();
			sendToAllConnectedSessions(addMessage);
		} else if (item.getName().equalsIgnoreCase(
				Appliances.AppliancesEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							HealthCareAppliances.HealthCareAppliancesEnum
									.getHealthCareAppliancesEnum())
					.add(WebSocketNavigationConstants.ACTION,
							HealthCareAppliances.HealthCareAppliancesEnum
									.getHealthCareAppliancesEnum()).build();
			sendToAllConnectedSessions(addMessage);
		}

		else if (item.getName().equalsIgnoreCase(
				BabyKids.BabyKidsEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							Toys.ToysEnum.getToysEnum())
					.add(WebSocketNavigationConstants.ACTION,
							Toys.ToysEnum.getToysEnum()).build();
			sendToAllConnectedSessions(addMessage);
		} else if (item.getName().equalsIgnoreCase(
				BabyKids.BabyKidsEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							KidsFootwear.KidsFootwearEnum.getKidsFootwearEnum())
					.add(WebSocketNavigationConstants.ACTION,
							KidsFootwear.KidsFootwearEnum.getKidsFootwearEnum())
					.build();
			sendToAllConnectedSessions(addMessage);
		} else if (item.getName().equalsIgnoreCase(
				BabyKids.BabyKidsEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							BabyCare.BabyCareEnum.getBabyCareEnum())
					.add(WebSocketNavigationConstants.ACTION,
							BabyCare.BabyCareEnum.getBabyCareEnum()).build();
			sendToAllConnectedSessions(addMessage);
		} else if (item.getName().equalsIgnoreCase(
				BabyKids.BabyKidsEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							BabyClothing.BabyClothingEnum.getBabyClothingEnum())
					.add(WebSocketNavigationConstants.ACTION,
							BabyClothing.BabyClothingEnum.getBabyClothingEnum())
					.build();
			sendToAllConnectedSessions(addMessage);
		}

		else if (item.getName().equalsIgnoreCase(
				HomeFurniture.HomeFurnitureEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							KitchenDining.KitchenDiningEnum
									.getKitchenDiningEnum())
					.add(WebSocketNavigationConstants.ACTION,
							KitchenDining.KitchenDiningEnum
									.getKitchenDiningEnum()).build();
			sendToAllConnectedSessions(addMessage);
		} else if (item.getName().equalsIgnoreCase(
				HomeFurniture.HomeFurnitureEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							Furniture.FurnitureEnum.getFurnitureEnum())
					.add(WebSocketNavigationConstants.ACTION,
							Furniture.FurnitureEnum.getFurnitureEnum()).build();
			sendToAllConnectedSessions(addMessage);
		} else if (item.getName().equalsIgnoreCase(
				HomeFurniture.HomeFurnitureEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							HomeDecor.HomeDecorEnum.getHomeDecorEnum())
					.add(WebSocketNavigationConstants.ACTION,
							HomeDecor.HomeDecorEnum.getHomeDecorEnum()).build();
			sendToAllConnectedSessions(addMessage);
		} else if (item.getName().equalsIgnoreCase(
				HomeFurniture.HomeFurnitureEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							LightingStore.LightingStoreEnum
									.getLightingStoreEnum())
					.add(WebSocketNavigationConstants.ACTION,
							LightingStore.LightingStoreEnum
									.getLightingStoreEnum()).build();
			sendToAllConnectedSessions(addMessage);
		}

		else if (item.getName().equalsIgnoreCase(Books.BooksEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							EducationalBooks.EducationalBooksEnum
									.getEducationalBooksEnum())
					.add(WebSocketNavigationConstants.ACTION,
							EducationalBooks.EducationalBooksEnum
									.getEducationalBooksEnum()).build();
			sendToAllConnectedSessions(addMessage);
		} else if (item.getName().equalsIgnoreCase(Books.BooksEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							EducationalBooks.EducationalBooksEnum
									.getEducationalBooksEnum())
					.add(WebSocketNavigationConstants.ACTION,
							EducationalBooks.EducationalBooksEnum
									.getEducationalBooksEnum()).build();
			sendToAllConnectedSessions(addMessage);
		} else if (item.getName().equalsIgnoreCase(Books.BooksEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							PhilosophyBooks.PhilosophyBooksEnum
									.getPhilosophyBooksEnum())
					.add(WebSocketNavigationConstants.ACTION,
							PhilosophyBooks.PhilosophyBooksEnum
									.getPhilosophyBooksEnum()).build();
			sendToAllConnectedSessions(addMessage);
		} else if (item.getName().equalsIgnoreCase(Books.BooksEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							IndianBooks.IndianBooksEnum.getIndianBooksEnum())
					.add(WebSocketNavigationConstants.ACTION,
							IndianBooks.IndianBooksEnum.getIndianBooksEnum())
					.build();
			sendToAllConnectedSessions(addMessage);
		}

		else if (item.getName().equalsIgnoreCase(Books.BooksEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							Religion.ReligionEnum.getReligionEnum())
					.add(WebSocketNavigationConstants.ACTION,
							Religion.ReligionEnum.getReligionEnum()).build();
			sendToAllConnectedSessions(addMessage);
		}

		else if (item.getName().equalsIgnoreCase(Gaming.GamingEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							MousePads.MousePadsEnum.getMousePadsEnum())
					.add(WebSocketNavigationConstants.ACTION,
							MousePads.MousePadsEnum.getMousePadsEnum()).build();
			sendToAllConnectedSessions(addMessage);
		} else if (item.getName()
				.equalsIgnoreCase(Gaming.GamingEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							Headsets.HeadsetsEnum.getHeadsetsEnum())
					.add(WebSocketNavigationConstants.ACTION,
							Headsets.HeadsetsEnum.getHeadsetsEnum()).build();
			sendToAllConnectedSessions(addMessage);
		} else if (item.getName()
				.equalsIgnoreCase(Gaming.GamingEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							Controllers.ControllersEnum.getControllersEnum())
					.add(WebSocketNavigationConstants.ACTION,
							Controllers.ControllersEnum.getControllersEnum())
					.build();
			sendToAllConnectedSessions(addMessage);
		} else if (item.getName()
				.equalsIgnoreCase(Gaming.GamingEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							Mouse.MouseEnum.getMouseEnum())
					.add(WebSocketNavigationConstants.ACTION,
							Mouse.MouseEnum.getMouseEnum()).build();
			sendToAllConnectedSessions(addMessage);
		}

		else if (item.getName().equalsIgnoreCase(Gaming.GamingEnum.toString())) {
			JsonProvider provider = JsonProvider.provider();
			JsonObject addMessage = provider
					.createObjectBuilder()
					.add(WebSocketNavigationConstants.NAME,
							Keyboards.KeyboardsEnum.getKeyboardsEnum())
					.add(WebSocketNavigationConstants.ACTION,
							Keyboards.KeyboardsEnum.getKeyboardsEnum()).build();
			sendToAllConnectedSessions(addMessage);
		}

	}

	/**
	 * To send an event message to all connected clients
	 * 
	 * @param message
	 *            the JsonObject
	 */
	private void sendToAllConnectedSessions(JsonObject message) {
		for (Session session : sessions) {
			sendToSession(session, message);
		}
	}

	/**
	 * To send an event message to a client.
	 * 
	 * @param session
	 *            the session token
	 * @param message
	 *            the JsonObject
	 */
	private void sendToSession(Session session, JsonObject message) {
		try {
			session.getBasicRemote().sendText(message.toString());
		} catch (IOException ex) {
			sessions.remove(session);
			Logger.getLogger(ItemSessionHandler.class.getName()).log(
					Level.SEVERE, null, ex);
		}
	}
}