package com.tataelxsi.websocket;

import static com.tataelxsi.constant.WebSocketNavigationConstants.ACTIONS;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.io.StringReader;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;

import com.tataelxsi.constant.WebSocketNavigationConstants;
import com.tataelxsi.model.Item;

	/**
	 * Web Socket Server implementation for ItemWebSocketServer operations.
	 * 
	 * @author Ganesh Devulapalli
	 * 
	 */

@ApplicationScoped
/*
 * Defining the WebSocket server endpoint
 */
@ServerEndpoint(ACTIONS)
public class ItemWebSocketServer {

	// Injecting the Session Handler class

	@Inject
	private ItemSessionHandler sessionHandler;

	@OnOpen
	public void open(Session session) {
	}

	@OnClose
	public void close(Session session) {
	}

	@OnError
	public void onError(Throwable error) {
		Logger.getLogger(ItemWebSocketServer.class.getName()).log(Level.SEVERE,
				null, error);

	}

	public void showSubCategoryItems(String s, ItemSessionHandler handler) {
		Item item = new Item();
		item.setName(s);
		handler.showSubCategoryItems(item);

	}

	/**
	 * @OnMessage annonation is mapped to handleMessage()
	 * 
	 * @param message
	 *            the message
	 * @param session
	 *            the session
	 */
	@OnMessage
	public void handleMessage(String message, Session session) {
		try (JsonReader reader = Json.createReader(new StringReader(message))) {
			JsonObject jsonMessage = reader.readObject();
			if (WebSocketNavigationConstants.ELECTRONICS
					.equalsIgnoreCase(jsonMessage
							.getString(WebSocketNavigationConstants.ACTION))
					|| WebSocketNavigationConstants.APPLIANCES
							.equalsIgnoreCase(jsonMessage
									.getString(WebSocketNavigationConstants.ACTION))
					|| WebSocketNavigationConstants.BABY_KIDS
							.equalsIgnoreCase(jsonMessage
									.getString(WebSocketNavigationConstants.ACTION))
					|| WebSocketNavigationConstants.HOME_FURNNITURE
							.equalsIgnoreCase(jsonMessage
									.getString(WebSocketNavigationConstants.ACTION))
					|| WebSocketNavigationConstants.BOOKS
							.equalsIgnoreCase(jsonMessage
									.getString(WebSocketNavigationConstants.ACTION))
					|| WebSocketNavigationConstants.GAMING
							.equalsIgnoreCase(jsonMessage
									.getString(WebSocketNavigationConstants.ACTION))) {
				Item item = new Item();
				sessionHandler.showElectronicsItems(item);
			} else {
				showSubCategoryItems(
						jsonMessage
								.getString(WebSocketNavigationConstants.ACTION),
						sessionHandler);
			}
		}

	}
}