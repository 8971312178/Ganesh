package com.tataelxsi.constant;

	/**
	 * Enumeration of HealthCareAppliances of Appliances.
	 * 
	 * @author Ganesh Devulapalli
	 *
	 */
public enum HealthCareAppliances {

	HealthCareAppliancesEnum("Livpure,Philips,V Guard,LG");

	private String healthCareAppliances;

	private HealthCareAppliances(String healthCareAppliances) {
		this.healthCareAppliances = healthCareAppliances;
	}

	public void setHealthCareAppliancesEnum(String healthCareAppliances) {
		this.healthCareAppliances = healthCareAppliances;
	}

	public String getHealthCareAppliancesEnum() {
		return healthCareAppliances;
	}

}
