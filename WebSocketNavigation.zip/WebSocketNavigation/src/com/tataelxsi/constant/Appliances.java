package com.tataelxsi.constant;

	/**
	 * Enumeration of Appliances of Category Item.
	 * 
	 * @author Ganesh Devulapalli
	 *
	 */
public enum Appliances {

	AppliancesEnum(
			"Washing Machines,Televisions,Refrigerators,Air conditioners,Small home appliances,Health care appliances");

	private String appliances;

	private Appliances(String appliances) {
		this.appliances = appliances;
	}

	public void setAppliancesEnum(String appliances) {
		this.appliances = appliances;
	}

	public String getAppliancesEnum() {
		return appliances;
	}

}
