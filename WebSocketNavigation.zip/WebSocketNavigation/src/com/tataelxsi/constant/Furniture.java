package com.tataelxsi.constant;

	/**
	 * Enumeration of Furniture of Category Items.
	 * 
	 * @author Ganesh Devulapalli
	 *
	 */

public enum Furniture {

	FurnitureEnum("HomeTown,Nilkamal,Springwel,National,Bharat");

	private String furniture;

	private Furniture(String furniture) {
		this.furniture = furniture;
	}

	public void setFurnitureEnum(String furniture) {
		this.furniture = furniture;
	}

	public String getFurnitureEnum() {
		return furniture;
	}

}
