package com.tataelxsi.constant;

/**
 * Enumeration of Televisions of Appliances.
 * 
 * @author Ganesh Devulapalli
 *
 */
public enum Televisions {

	TelevisionsEnum("Sony,Samsung,LG,Hisense,VU,Cloudwalker");

	private String televisions;

	private Televisions(String televisions) {
		this.televisions = televisions;
	}

	public void setTelevisionsEnum(String televisions) {
		this.televisions = televisions;
	}

	public String getTelevisionsEnum() {
		return televisions;
	}

}
