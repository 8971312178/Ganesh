package com.tataelxsi.constant;

	/**
	 * Enumeration of BabyCare of Baby and Kids.
	 * 
	 * @author Ganesh Devulapalli
	 *
	 */
public enum BabyCare {

	BabyCareEnum("Himalaya,Aaram,Babeezworld,United Colors of Benetton");

	private String babyCare;

	private BabyCare(String babyCare) {
		this.babyCare = babyCare;
	}

	public void setBabyCareEnum(String babyCare) {
		this.babyCare = babyCare;
	}

	public String getBabyCareEnum() {
		return babyCare;
	}

}
