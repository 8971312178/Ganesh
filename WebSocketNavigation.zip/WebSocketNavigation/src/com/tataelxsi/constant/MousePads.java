package com.tataelxsi.constant;

/**
 * Enumeration of MousePads of Gaming.
 * 
 * @author Ganesh Devulapalli
 *
 */
public enum MousePads {

	MousePadsEnum("3M ERGO,Ad Net,Anwesha's,Asus,Circle");

	private String mousePads;

	private MousePads(String mousePads) {
		this.mousePads = mousePads;
	}

	public void setMousePadsEnum(String mousePads) {
		this.mousePads = mousePads;
	}

	public String getMousePadsEnum() {
		return mousePads;
	}

}
