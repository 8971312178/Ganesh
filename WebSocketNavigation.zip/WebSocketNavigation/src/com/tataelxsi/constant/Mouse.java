package com.tataelxsi.constant;

/**
 * Enumeration of Mouse of Gaming.
 * 
 * @author Ganesh Devulapalli
 *
 */
public enum Mouse {

	MouseEnum("Logitech,Dragon War,SteelSeries,Zebronics,Razer");

	private String mouse;

	private Mouse(String mouse) {
		this.mouse = mouse;
	}

	public void setMouseEnum(String mouse) {
		this.mouse = mouse;
	}

	public String getMouseEnum() {
		return mouse;
	}

}
