package com.tataelxsi.constant;

	/**
	 * Enumeration of BabyKids of Category .
	 * 
	 * @author Ganesh Devulapalli
	 *
	 */
public enum BabyKids {

	BabyKidsEnum("Toys,Kids Footwear,Baby Care,Baby Boy Clothing");

	private String babyKids;

	private BabyKids(String babyKids) {
		this.babyKids = babyKids;
	}

	public void setBabyKidsEnum(String babyKids) {
		this.babyKids = babyKids;
	}

	public String getBabyKidsEnum() {
		return babyKids;
	}

}
