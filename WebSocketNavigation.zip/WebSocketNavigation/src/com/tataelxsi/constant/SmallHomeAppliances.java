package com.tataelxsi.constant;

/**
 * Enumeration of SmallHomeAppliances of Appliances.
 * 
 * @author Ganesh Devulapalli
 *
 */
public enum SmallHomeAppliances {

	SmallHomeAppliancesEnum("Livpure,Philips,V Guard,LG");

	private String smallHomeAppliances;

	private SmallHomeAppliances(String smallHomeAppliances) {
		this.smallHomeAppliances = smallHomeAppliances;
	}

	public void setSmallHomeAppliancesEnum(String smallHomeAppliances) {
		this.smallHomeAppliances = smallHomeAppliances;
	}

	public String getSmallHomeAppliancesEnum() {
		return smallHomeAppliances;
	}

}
