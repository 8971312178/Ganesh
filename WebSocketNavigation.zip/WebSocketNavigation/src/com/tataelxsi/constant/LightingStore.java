package com.tataelxsi.constant;

/**
 * Enumeration of LightingStore of Home & Furniture.
 * 
 * @author Ganesh Devulapalli
 *
 */
public enum LightingStore {

	LightingStoreEnum("Philips,Syska,Wipro,Crompton,Bajaj");

	private String lightingStore;

	private LightingStore(String lightingStore) {
		this.lightingStore = lightingStore;
	}

	public void setLightingStoreEnum(String lightingStore) {
		this.lightingStore = lightingStore;
	}

	public String getLightingStoreEnum() {
		return lightingStore;
	}

}
