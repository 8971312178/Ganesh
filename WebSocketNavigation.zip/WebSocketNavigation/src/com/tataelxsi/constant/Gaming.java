/**
 * 
 */
package com.tataelxsi.constant;

	/**
	 * Enumeration of Gaming of Category Items.
	 * 
	 * @author Ganesh Devulapalli
	 *
	 */
public enum Gaming {

	GamingEnum("Mouse Pads,Headsets & Speakers,Controllers,Mouse,Keyboards");

	private String gaming;

	private Gaming(String gaming) {
		this.gaming = gaming;
	}

	public void setGamingEnum(String gaming) {
		this.gaming = gaming;
	}

	public String getGamingEnum() {
		return gaming;
	}

}
