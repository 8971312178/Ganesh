package com.tataelxsi.constant;

	/**
	 * Enumeration of Books of Category .
	 * 
	 * @author Ganesh Devulapalli
	 *
	 */

public enum Books {

	BooksEnum(
			"Educational and Professional Books,Fiction & Non-Fiction Books,Philosophy Books,Indian Writing Books,Religion & Spirituality Books");

	private String books;

	private Books(String books) {
		this.books = books;
	}

	public void setBooksEnum(String books) {
		this.books = books;
	}

	public String getBooksEnum() {
		return books;
	}
}
