package com.tataelxsi.constant;

/**
 * Enumeration of Toys of Gaming.
 * 
 * @author Ganesh Devulapalli
 *
 */

public enum Toys {

	ToysEnum("Fisher Price,Intex,Toyzone,M & M PRODUCTS,ShengShou,Syga");

	private String toys;

	private Toys(String toys) {
		this.toys = toys;
	}

	public void setToysEnum(String toys) {
		this.toys = toys;
	}

	public String getToysEnum() {
		return toys;
	}

}
