package com.tataelxsi.constant;

	/**
	 * Enumeration of KidsFootwear of Baby & Kids.
	 * 
	 * @author Ganesh Devulapalli
	 *
	 */
public enum KidsFootwear {

	KidsFootwearEnum("Adidas,Reebok,Nike,Trilokani,D'chica,D'chica");

	private String kidsFootwear;

	private KidsFootwear(String kidsFootwear) {
		this.kidsFootwear = kidsFootwear;
	}

	public void setKidsFootwearEnum(String kidsFootwear) {
		this.kidsFootwear = kidsFootwear;
	}

	public String getKidsFootwearEnum() {
		return kidsFootwear;
	}

}
