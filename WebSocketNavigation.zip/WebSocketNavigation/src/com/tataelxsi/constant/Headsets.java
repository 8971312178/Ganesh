package com.tataelxsi.constant;

	/**
	 * Enumeration of Headsets of Gaming.
	 * 
	 * @author Ganesh Devulapalli
	 *
	 */
public enum Headsets {

	HeadsetsEnum("Amkette,ANIMATE,Blue Birds USA Homewares,Bluei,Dragon War");

	private String headsets;

	private Headsets(String headsets) {
		this.headsets = headsets;
	}

	public void setHeadsetsEnum(String headsets) {
		this.headsets = headsets;
	}

	public String getHeadsetsEnum() {
		return headsets;
	}

}
