package com.tataelxsi.constant;

/**
 * Enumeration of Religion of Books.
 * 
 * @author Ganesh Devulapalli
 *
 */

public enum Religion {
	
	ReligionEnum("Holy Books,New Age and Occult,Spirituality,Baha'i,Religions");

	private String religion;

	private Religion(String religion) {
		this.religion = religion;
	}

	public void setReligionEnum(String religion) {
		this.religion = religion;
	}

	public String getReligionEnum() {
		return religion;
	}

}
