package com.tataelxsi.constant;

	/**
	 * Enumeration of AirConditioners of Appliances.
	 * 
	 * @author Ganesh Devulapalli
	 *
	 */
public enum AirConditioners {

	AirConditionersEnum("Samsung,Hitachi,Voltas,LG,Blue Star,Lloyd");

	private String airConditioners;

	private AirConditioners(String airConditioners) {
		this.airConditioners = airConditioners;
	}

	public void setAirConditionersEnum(String airConditioners) {
		this.airConditioners = airConditioners;
	}

	public String getAirConditionersEnum() {
		return airConditioners;
	}

}
