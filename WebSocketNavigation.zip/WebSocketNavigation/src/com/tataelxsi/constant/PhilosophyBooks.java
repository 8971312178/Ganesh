package com.tataelxsi.constant;

/**
 * Enumeration of PhilosophyBooks of Books.
 * 
 * @author Ganesh Devulapalli
 *
 */
public enum PhilosophyBooks {

	PhilosophyBooksEnum(
			"Movements,Free Will & Determinism,Reference,Epistemology,Political");

	private String philosophyBooks;

	private PhilosophyBooks(String philosophyBooks) {
		this.philosophyBooks = philosophyBooks;
	}

	public void setPhilosophyBooksEnum(String philosophyBooks) {
		this.philosophyBooks = philosophyBooks;
	}

	public String getPhilosophyBooksEnum() {
		return philosophyBooks;
	}
}
