package com.tataelxsi.constant;

/**
 * Enumeration of Refrigerators of Appliances.
 * 
 * @author Ganesh Devulapalli
 *
 */
public enum Refrigerators {
	
	
	RefrigeratorsEnum("Samsung,Whirlpool,LG,Godrej,Kelvinator");

	private String refrigerators;

	private Refrigerators(String refrigerators) {
		this.refrigerators = refrigerators;
	}

	public void setRefrigeratorsEnum(String refrigerators) {
		this.refrigerators = refrigerators;
	}

	public String getRefrigeratorsEnum() {
		return refrigerators;
	}


}
