package com.tataelxsi.constant;

/**
 * Enumeration of Tablet of Electronics.
 * 
 * @author Ganesh Devulapalli
 *
 */
public enum Tablet {

	TabletEnum("Apple,Lenovo,Alcatel,Datawind,Samsung");

	private String tablet;

	private Tablet(String tablet) {
		this.tablet = tablet;
	}

	public void setTabletEnum(String tablet) {
		this.tablet = tablet;
	}

	public String getTabletEnum() {
		return tablet;
	}

}
