package com.tataelxsi.constant;

	/**
	 * Enumeration of FictionBooks of Books.
	 * 
	 * @author Ganesh Devulapalli
	 *
	 */

public enum FictionBooks {

	FictionBooksEnum(
			"Business,Investing and Management Books,Coffee Table Books Art,Architecture & Design Books,Health & Fitness Books");

	private String fictionBooks;

	private FictionBooks(String fictionBooks) {
		this.fictionBooks = fictionBooks;
	}

	public void setFictionBooksEnum(String fictionBooks) {
		this.fictionBooks = fictionBooks;
	}

	public String getFictionBooksEnum() {
		return fictionBooks;
	}

}
