package com.tataelxsi.constant;

	/**
	 * Enumeration of KitchenDining of Home & Furniture.
	 * 
	 * @author Ganesh Devulapalli
	 *
	 */
public enum KitchenDining {

	KitchenDiningEnum("Pigeon,Prestige,Hawkins,Tupperware,Milton");

	private String kitchenDining;

	private KitchenDining(String kitchenDining) {
		this.kitchenDining = kitchenDining;
	}

	public void setKitchenDiningEnum(String kitchenDining) {
		this.kitchenDining = kitchenDining;
	}

	public String getKitchenDiningEnum() {
		return kitchenDining;
	}

}
