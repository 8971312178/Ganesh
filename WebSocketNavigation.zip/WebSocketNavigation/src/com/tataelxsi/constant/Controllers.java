package com.tataelxsi.constant;

	/**
	 * Enumeration of Controllers of Gaming .
	 * 
	 * @author Ganesh Devulapalli
	 *
	 */
public enum Controllers {

	ControllersEnum("Ae zone,Amkette,Arkey,Augmento,Deal");

	private String controllers;

	private Controllers(String controllers) {
		this.controllers = controllers;
	}

	public void setControllersEnum(String controllers) {
		this.controllers = controllers;
	}

	public String getControllersEnum() {
		return controllers;
	}

}
