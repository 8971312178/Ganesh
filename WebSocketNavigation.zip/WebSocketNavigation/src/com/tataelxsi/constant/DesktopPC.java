package com.tataelxsi.constant;

	/**
	 * Enumeration of DesktopPC of Electronics .
	 * 
	 * @author Ganesh Devulapalli
	 *
	 */
public enum DesktopPC {

	DesktopPCEnum("HP,Apple,Lenovo,Dell,Acer");

	private String DesktopPc;

	private DesktopPC(String desktopPc) {
		DesktopPc = desktopPc;
	}

	public String getDesktopPcEnum() {
		return DesktopPc;
	}

	public void setDesktopPcEnum(String desktopPc) {
		DesktopPc = desktopPc;
	}

}
