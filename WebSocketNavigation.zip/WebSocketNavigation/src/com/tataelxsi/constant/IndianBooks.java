package com.tataelxsi.constant;

	/**
	 * Enumeration of IndianBooks of Books.
	 * 
	 * @author Ganesh Devulapalli
	 *
	 */
public enum IndianBooks {

	IndianBooksEnum(
			"Travel Books,History and Politics Books,Business,Investing and Management Books,Literature & Fiction Books");

	private String indianBooks;

	private IndianBooks(String indianBooks) {
		this.indianBooks = indianBooks;
	}

	public void setIndianBooksEnum(String indianBooks) {
		this.indianBooks = indianBooks;
	}

	public String getIndianBooksEnum() {
		return indianBooks;
	}

}
