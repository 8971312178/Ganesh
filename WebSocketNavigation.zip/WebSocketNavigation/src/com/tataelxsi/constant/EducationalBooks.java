package com.tataelxsi.constant;

	/**
	 * Enumeration of EducationalBooks of Books .
	 * 
	 * @author Ganesh Devulapalli
	 *
	 */

public enum EducationalBooks {

	EducationalBooksEnum(
			"Academic Texts Books,Entrance Exams Preparation Books,Medical Books,Computers & Internet Books,School Books");

	private String educationalBooks;

	private EducationalBooks(String educationalBooks) {
		this.educationalBooks = educationalBooks;
	}

	public void setEducationalBooksEnum(String educationalBooks) {
		this.educationalBooks = educationalBooks;
	}

	public String getEducationalBooksEnum() {
		return educationalBooks;
	}

}
