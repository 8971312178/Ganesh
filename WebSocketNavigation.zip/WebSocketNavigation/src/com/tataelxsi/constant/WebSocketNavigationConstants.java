package com.tataelxsi.constant;

/**
 * Constants definitions across the application.
 * 
 * @author Ganesh Devulapalli
 * 
 */

public class WebSocketNavigationConstants {
	
	/* String constants */	
	public static final String ELECTRONICS = "Electronics";
	public static final String APPLIANCES = "Appliances";
	public static final String BABY_KIDS = "BabyKids";
	public static final String HOME_FURNNITURE = "HomeFurniture";
	public static final String BOOKS = "Books";
	public static final String GAMING = "Gaming";
	public static final String NAME = "name";
	public static final String ACTION = "action";
	
	// Resource Root Paths
	public static final String ACTIONS = "/actions";
	/*
	 * Making constructor private so that an instance of this class can never be
	 * created.
	 */
	private WebSocketNavigationConstants() {
	}


}
