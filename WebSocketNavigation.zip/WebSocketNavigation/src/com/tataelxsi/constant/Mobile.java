package com.tataelxsi.constant;

/**
 * Enumeration of Mobile of Electronics.
 * 
 * @author Ganesh Devulapalli
 *
 */
public enum Mobile {

	MobileEnum("Apple,Samsung,Motorola,Lenovo,OPPO,Mi");

	private String mobile;

	private Mobile(String mobile) {
		this.mobile = mobile;
	}

	public void setMobileEnum(String mobile) {
		this.mobile = mobile;
	}

	public String getMobileEnum() {
		return mobile;
	}

}
