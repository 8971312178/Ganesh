package com.tataelxsi.constant;

	/**
	 * Enumeration of HomeFurniture of Category.
	 * 
	 * @author Ganesh Devulapalli
	 *
	 */
public enum HomeFurniture {

	HomeFurnitureEnum("Kitchen & Dining,Furniture,Home Decor,Lighting Store");

	private String homeFurniture;

	private HomeFurniture(String homeFurniture) {
		this.homeFurniture = homeFurniture;
	}

	public void setHomeFurnitureEnum(String homeFurniture) {
		this.homeFurniture = homeFurniture;
	}

	public String getHomeFurnitureEnum() {
		return homeFurniture;
	}

}
