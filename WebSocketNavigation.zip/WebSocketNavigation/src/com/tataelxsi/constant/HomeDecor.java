package com.tataelxsi.constant;

	/**
	 * Enumeration of HomeDecor of Home.
	 * 
	 * @author Ganesh Devulapalli
	 *
	 */
public enum HomeDecor {

	HomeDecorEnum("Ajanta,JaipurCrafts,Sehaz Artworks,eCraftIndia,Philips");

	private String homeDecor;

	private HomeDecor(String homeDecor) {
		this.homeDecor = homeDecor;
	}

	public void setHomeDecorEnum(String homeDecor) {
		this.homeDecor = homeDecor;
	}

	public String getHomeDecorEnum() {
		return homeDecor;
	}

}
