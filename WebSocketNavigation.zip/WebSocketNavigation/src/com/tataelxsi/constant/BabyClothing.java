package com.tataelxsi.constant;

	/**
	 * Enumeration of BabyClothing of Baby and Kids.
	 * 
	 * @author Ganesh Devulapalli
	 *
	 */
public enum BabyClothing {

	BabyClothingEnum("Adidas,Mother Care,PalmTree,Little Kangaroos");

	private String babyClothing;

	private BabyClothing(String babyClothing) {
		this.babyClothing = babyClothing;
	}

	public void setBabyClothingEnum(String babyClothing) {
		this.babyClothing = babyClothing;
	}

	public String getBabyClothingEnum() {
		return babyClothing;
	}

}
