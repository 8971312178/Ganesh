package com.tataelxsi.constant;

	/**
	 * Enumeration of Laptop of Electronics.
	 * 
	 * @author Ganesh Devulapalli
	 *
	 */
public enum Laptop {

	LaptopEnum("HP,Lenovo,Dell,Acer,Apple,Toshiba,Samsung");

	private String laptop;

	private Laptop(String laptop) {
		this.laptop = laptop;
	}

	public void setLaptopEnum(String laptop) {
		this.laptop = laptop;
	}

	public String getLaptopEnum() {
		return laptop;
	}

}
