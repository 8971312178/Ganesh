package com.tataelxsi.constant;

	/**
	 * Enumeration of Keyboards of Gaming.
	 * 
	 * @author Ganesh Devulapalli
	 *
	 */

public enum Keyboards {

	KeyboardsEnum("Astrum,Asus,BACKLINK,Circle");

	private String keyboards;

	private Keyboards(String keyboards) {
		this.keyboards = keyboards;
	}

	public void setKeyboardsEnum(String keyboards) {
		this.keyboards = keyboards;
	}

	public String getKeyboardsEnum() {
		return keyboards;
	}

}
