/**
 * 
 */
package com.tataelxsi.constant;

/**
 * Enumeration of WashingMachines of Appliances.
 * 
 * @author Ganesh Devulapalli
 *
 */
public enum WashingMachines {

	WashingMachinesEnum(
			"Whirlpool,IFB,Samsung,LG,Godrej,Bosch,Electrolux,Siemens");

	private String washingMachines;

	private WashingMachines(String washingMachines) {
		this.washingMachines = washingMachines;
	}

	public void setMobileEnum(String washingMachines) {
		this.washingMachines = washingMachines;
	}

	public String getWashingMachinesEnum() {
		return washingMachines;
	}

}
