package com.tataelxsi.constant;

	/**
	 * Enumeration of Electronics of Category Item .
	 * 
	 * @author Ganesh Devulapalli
	 *
	 */
public enum Electronics {

	ElectronicsEnum("Mobiles,Laptops,Tablets,Desktop PC's");

	private String electronics;

	private Electronics(String electronics) {
		this.electronics = electronics;
	}

	public void setElectronicsEnum(String electronics) {
		this.electronics = electronics;
	}

	public String getElectronicsEnum() {
		return electronics;
	}

}
