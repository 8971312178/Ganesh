
window.onload = init;
var socket = new WebSocket("ws://localhost:8080/WebSocketNavigation/actions");
socket.onmessage = onMessage;
function onMessage(event) {
    var item = JSON.parse(event.data);
    if (item.action == "Electronics" || item.action == "Appliances" || item.action == "BabyKids" || item.action == "HomeFurniture" || item.action == "Books" || item.action == "Gaming") 
	{
        displayShowMenuData(item);
    }
        }
function displayShowMenuData(item) {
   var content = document.getElementById("content");  
   content.innerHTML = "<li class='-hasSubmenu'>" + item.name + "</li>";
}
function init() {
     
}